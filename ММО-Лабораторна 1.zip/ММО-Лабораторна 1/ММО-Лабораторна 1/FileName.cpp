#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double x;
    cin >> x;

    int order;
    double mantissa;

    if (x == 0) {
        mantissa = 0;
        order = 0;
    }
    else {
        order = (int)floor(log10(fabs(x)));
        mantissa = x / pow(10, order);

        while (fabs(mantissa) >= 1.0) {
            mantissa /= 10.0;
            order++;
        }
        while (fabs(mantissa) < 0.1) {
            mantissa *= 10.0;
            order--;
        }
    }

    cout << mantissa << " * 10^" << order;
    return 0;
}
