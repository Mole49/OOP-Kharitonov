#include <iostream>
using namespace std;

struct Pair {
    double first;
    int second;

    void Init(double f, int s) {
        if (f > 0 && s > 0) {
            first = f;
            second = s;
        }
        else {
            first = 1.0;
            second = 1;
        }
    }

    void Read() {
        double f;
        int s;
        cout << "Enter price: ";
        cin >> f;
        cout << "Enter quantity: ";
        cin >> s;
        Init(f, s);
    }

    void Display() {
        cout << "Price: " << first << ", Quantity: " << second
            << ", Cost: " << cost() << endl;
    }

    double cost() {
        return first * second;
    }
};

int main() {
    Pair p;
    p.Read();
    p.Display();
    return 0;
}
